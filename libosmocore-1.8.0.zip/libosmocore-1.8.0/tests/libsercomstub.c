/* Stubs for embedded build */
void sercomm_drv_lock(unsigned long __attribute__((unused)) *flags) {}
void sercomm_drv_unlock(unsigned long __attribute__((unused)) *flags) {}
