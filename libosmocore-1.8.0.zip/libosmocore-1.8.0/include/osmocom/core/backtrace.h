/*! \file backtrace.h */

#pragma once

void osmo_generate_backtrace(void);
void osmo_log_backtrace(int subsys, int level);
