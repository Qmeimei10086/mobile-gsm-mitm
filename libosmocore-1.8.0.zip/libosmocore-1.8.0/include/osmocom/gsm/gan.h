/*! \file gan.h */

#pragma once

#include <osmocom/core/utils.h>

extern const struct value_string gan_msgt_vals[];
static const struct value_string gan_pdisc_vals[];
