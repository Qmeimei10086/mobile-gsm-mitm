#pragma once
#include <osmocom/isdn/lapd_core.h>
