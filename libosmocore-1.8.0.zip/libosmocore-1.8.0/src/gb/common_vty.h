/*! \file common_vty.h */

#include <osmocom/vty/command.h>
#include <osmocom/core/logging.h>

extern int DNS;

