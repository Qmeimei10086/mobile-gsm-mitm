#ifndef _GPRS_NS_FRGRE_H
#define _GPRS_NS_FRGRE_H

int gprs_ns_frgre_sendmsg(struct gprs_nsvc *nsvc, struct msgb *msg);

#endif
