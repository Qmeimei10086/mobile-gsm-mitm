#ifndef _OSMO_GSM_GAN_H
#define  _OSMO_GSM_GAN_H

#include <osmocom/core/utils.h>

extern const struct value_string gan_msgt_vals[];
static const struct value_string gan_pdisc_vals[];

#endif
