#warning "Update from osmocom/core/process.h to osmocom/core/application.h"
#include <osmocom/core/application.h>
