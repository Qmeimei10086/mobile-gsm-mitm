#pragma once

int layer23_random(void);
