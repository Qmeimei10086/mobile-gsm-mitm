#pragma once

struct osmocom_ms;

int fps_start(struct osmocom_ms *ms);
int fps_init(void);
